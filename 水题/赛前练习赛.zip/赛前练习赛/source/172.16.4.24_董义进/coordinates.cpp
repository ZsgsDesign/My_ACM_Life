#include<bits/stdc++.h>
using namespace std;
int main(){
	
	freopen("coordinates.in",r,stdin);
	freopen("coordinates.out",w,stdout);
	cout<<"*.........|........"<<endl;
	cout<<".*........|........"<<endl;
	cout<<"...*......|........"<<endl;
	cout<<"......*...|........"<<endl;
	cout<<"..........*........"<<endl;
	cout<<"----------+--------"<<endl;
	cout<<"..........|.....*.."<<endl;
	cout<<"..........|........"<<endl;
	cout<<"..........|.......*"<<endl;
  return 0;
}
