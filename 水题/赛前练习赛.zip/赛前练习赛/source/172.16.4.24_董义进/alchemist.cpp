#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("alchemist.in",r,stdin);
	freopen("alchemist.out",w,stdout);
    cout<<28;
		
	return 0;
}
